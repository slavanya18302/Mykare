import { useContext, useState } from "react"
import { ActivityIndicator, Alert, Image, KeyboardAvoidingView, Pressable, ScrollView, StatusBar, Text, TouchableOpacity, View } from "react-native"
import { Icon, Input } from "@rneui/themed"
import { useNavigation } from "@react-navigation/native"
import AsyncStorage from "@react-native-async-storage/async-storage"
import { useFormik } from "formik"
import * as yup from "yup"
import { createUserWithEmailAndPassword, getAuth } from "@react-native-firebase/auth"

import { appFont } from "../../shared/appFont"
import { appColors } from "../../shared/appColor"
import UserContext from "../../shared/userContext"

const SignUp = () => {
    const navigation = useNavigation()
    const [loader, setLoader] = useState(false)
    const [eye, setEye] = useState(false)
    const { setIsLogedIn } = useContext(UserContext)

    const formik = useFormik({
        initialValues: {
            name: "",
            email: "",
            password: "",
            role: ""
        },
        validationSchema: yup.object().shape({
            name: yup.string().min(5, "Username must have minimum 5 character")
                .max(10, "Maximum 10 characters allowed")
                .matches(/^[A-Za-z]+$/, "Only Characters are allowed"),
            email: yup.string().required("This field is required").email("Enter valid email"),
            password: yup.string().required("This field is required").matches(/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d@$!%*?&]{6,}$/, "Enter valid password"),
            role: yup.string().required("This field is required").trim().lowercase().oneOf(['user', 'admin'], 'Role must be "Admin" or "User"')
        }),
        onSubmit: () => { createAccount() }
    })

    const createAccount = () => {
        setLoader(true)
        createUserWithEmailAndPassword(getAuth(), formik.values?.email, formik.values?.password).then(async (res) => {
            const data = {
                UserId: res?.user?.uid,
                Username: formik.values.name,
                Email: formik.values.email,
                Role: formik.values.role
            }
            await AsyncStorage.setItem("userID", res?.user?.uid)
            const storedUsers = await AsyncStorage.getItem("allUsers");
            const parsedUsers = storedUsers ? JSON.parse(storedUsers) : []
            const updatedUsers = parsedUsers?.length > 0 ? [...parsedUsers, data] : [data];
            await AsyncStorage.setItem("allUsers", JSON.stringify(updatedUsers));

            setIsLogedIn(true)
            setLoader(false)
        }).catch((error) => {
            setLoader(false)
            Alert.alert("Warning", error.message.replace(/^\[.*\]\s*/, ''))
            console.log("Error while signup", error)
        })
    }

    return (
        <KeyboardAvoidingView enabled style={{ flex: 1, backgroundColor: appColors.light }}>
            <StatusBar backgroundColor={appColors.primary} />
            <ScrollView scrollEnabled={true} contentContainerStyle={{ flexGrow: 1, marginTop: 10 }}>
                <View style={{ justifyContent: "center", alignItems: "center" }}>
                    <Image source={require("../../assets/images/logo.png")} style={{ height: 100, width: 120, marginTop: 20 }} />
                    <Text style={{ fontFamily: appFont.bold, paddingVertical: 10 }}>Welcome!</Text>
                    <Text style={{ fontFamily: appFont.medium }}>Create your account</Text>
                </View>
                <View style={{ marginTop: 30, paddingHorizontal: 20 }}>
                    <Input
                        placeholder="Username"
                        value={formik.values.name}
                        onChangeText={(text) => formik.setFieldValue("name", text)}
                        onBlur={() => { formik.setFieldTouched("name", true); formik.handleBlur("name") }}
                        leftIcon={
                            <View style={{ backgroundColor: "white", paddingVertical: 20, paddingHorizontal: 20, borderRadius: 35, elevation: 5, position: "absolute", marginLeft: 40 }}>
                                <Icon type="font-awesome" name="user-o" color={appColors.primary} />
                            </View>
                        }
                        errorMessage={formik.touched.name && formik.errors.name ? formik.errors.name : undefined}
                        errorStyle={{ paddingHorizontal: 35 }}
                        inputStyle={{ marginLeft: 65, height: 55 }}
                        inputContainerStyle={{ borderWidth: 0, borderBottomWidth: 0, backgroundColor: "white", borderRadius: 25, elevation: 5 }}
                    />
                    <Input
                        placeholder="Email"
                        value={formik.values.email}
                        onChangeText={(text) => formik.setFieldValue("email", text)}
                        onBlur={() => { formik.setFieldTouched("email", true); formik.handleBlur("email") }}
                        leftIcon={
                            <View style={{ backgroundColor: "white", paddingVertical: 20, paddingHorizontal: 20, borderRadius: 35, elevation: 5, position: "absolute", marginLeft: 40 }}>
                                <Icon type="material-community" name="email-outline" color={appColors.primary} />
                            </View>
                        }
                        keyboardType="email-address"
                        errorMessage={formik.touched.email && formik.errors.email ? formik.errors.email : undefined}
                        errorStyle={{ paddingHorizontal: 35 }}
                        inputStyle={{ marginLeft: 65, height: 55, marginRight: 10 }}
                        inputContainerStyle={{ borderWidth: 0, borderBottomWidth: 0, backgroundColor: "white", borderRadius: 25, elevation: 5 }}
                    />
                    <Input
                        placeholder="Password"
                        value={formik.values.password}
                        onChangeText={(text) => formik.setFieldValue("password", text)}
                        onBlur={() => { formik.setFieldTouched("password", true); formik.handleBlur("password") }}
                        leftIcon={
                            <View style={{ backgroundColor: "white", paddingVertical: 20, paddingHorizontal: 20, borderRadius: 35, elevation: 5, position: "absolute", marginLeft: 40 }}>
                                <Icon type="material-community" name="lock-outline" color={appColors.primary} />
                            </View>
                        }
                        secureTextEntry={!eye}
                        rightIcon={
                            <Pressable style={{ paddingHorizontal: 15 }} onPress={() => setEye(!eye)}>
                                <Icon type="material-community" name={eye ? "eye" : "eye-off"} color={appColors.primary} size={20} />
                            </Pressable>
                        }
                        errorMessage={formik.touched.password && formik.errors.password ? formik.errors.password : undefined}
                        errorStyle={{ paddingHorizontal: 35 }}
                        inputStyle={{ marginLeft: 65, height: 55 }}
                        inputContainerStyle={{ borderWidth: 0, borderBottomWidth: 0, backgroundColor: "white", borderRadius: 25, elevation: 5 }}
                    />
                    <Input
                        placeholder="Role"
                        value={formik.values.role}
                        onChangeText={(text) => formik.setFieldValue("role", text)}
                        onBlur={() => { formik.setFieldTouched("role", true); formik.handleBlur("role") }}
                        leftIcon={
                            <View style={{ backgroundColor: "white", paddingVertical: 20, paddingHorizontal: 20, borderRadius: 35, elevation: 5, position: "absolute", marginLeft: 40 }}>
                                <Icon type="font-awesome" name="user-o" color={appColors.primary} />
                            </View>
                        }
                        errorMessage={formik.touched.role && formik.errors.role ? formik.errors.role : undefined}
                        errorStyle={{ paddingHorizontal: 35 }}
                        inputStyle={{ marginLeft: 65, height: 55 }}
                        inputContainerStyle={{ borderWidth: 0, borderBottomWidth: 0, backgroundColor: "white", borderRadius: 25, elevation: 5 }}
                    />
                    <TouchableOpacity onPress={() => formik.handleSubmit()} activeOpacity={0.7} style={{ backgroundColor: appColors.primary, marginHorizontal: 15, paddingVertical: 15, alignItems: "center", borderRadius: 10, marginTop: 20 }}>
                        {loader ? <ActivityIndicator color={appColors.light} /> : <Text style={{ fontFamily: appFont.bold, color: appColors.light }}>SignUp</Text>}
                    </TouchableOpacity>
                    <Text style={{ fontFamily: appFont.medium, color: appColors.grey, marginTop: 30, textAlign: "center", paddingBottom: 40 }}>Already have an account? <Text onPress={() => navigation.navigate("login")} style={{ color: appColors.primary, textDecorationLine: "underline" }}>Login</Text></Text>
                </View>
            </ScrollView>
        </KeyboardAvoidingView>
    )
}

export default SignUp