import { useContext, useState } from "react"
import { ActivityIndicator, Alert, Image, KeyboardAvoidingView, Pressable, ScrollView, StatusBar, Text, TextInput, TouchableOpacity, View } from "react-native"
import { Divider, Icon, Input } from "@rneui/themed"
import { useNavigation } from "@react-navigation/native"
import AsyncStorage from "@react-native-async-storage/async-storage"
import { useFormik } from "formik"
import * as yup from "yup"
import { getAuth, signInWithEmailAndPassword } from "@react-native-firebase/auth"

import { appFont } from "../../shared/appFont"
import { appColors } from "../../shared/appColor"
import UserContext from "../../shared/userContext"

const Login = () => {

    const navigation = useNavigation()
    const [loader, setLoader] = useState(false)
    const [eye, setEye] = useState(false)
    const { setIsLogedIn } = useContext(UserContext)

    const formik = useFormik({
        initialValues: {
            email: "",
            password: ""
        },
        validationSchema: yup.object().shape({
            email: yup.string().required("This field is required").email("Enter valid email"),
            password: yup.string().required("This field is required").matches(/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d@$!%*?&]{6,}$/, "Enter valid password")
        }),
        onSubmit: () => { signIn() }
    })

    const signIn = () => {
        setLoader(true)
        signInWithEmailAndPassword(getAuth(), formik.values.email, formik.values.password).then(async (res) => {
            await AsyncStorage.setItem("userID", res?.user?.uid)
            setIsLogedIn(true)
            setLoader(false)
        }).catch(error => {
            setLoader(false)
            Alert.alert("Warning", error.message.replace(/^\[.*\]\s*/, ''))
        })
    }

    return (
        <KeyboardAvoidingView enabled style={{ flex: 1, backgroundColor: appColors.light }}>
            <StatusBar backgroundColor={appColors.primary} />
            <ScrollView scrollEnabled={true} contentContainerStyle={{ flexGrow: 1, marginTop: 20 }}>
                <View style={{ justifyContent: "center", alignItems: "center" }}>
                    <Image source={require("../../assets/images/logo.png")} style={{ height: 100, width: 120, marginTop: 20 }} />
                    <Text style={{ fontFamily: appFont.bold, paddingVertical: 10 }}>Welcome back!</Text>
                    <Text style={{ fontFamily: appFont.medium }}>Login to your account</Text>
                </View>
                <View style={{ marginTop: 30, paddingHorizontal: 20 }}>
                    <Input
                        placeholder="Email"
                        value={formik.values.email}
                        onChangeText={(text) => formik.setFieldValue("email", text)}
                        onBlur={() => { formik.setFieldTouched("email", true); formik.handleBlur("email") }}
                        leftIcon={
                            <View style={{ backgroundColor: "white", paddingVertical: 20, paddingHorizontal: 20, borderRadius: 35, elevation: 5, position: "absolute", marginLeft: 40 }}>
                                <Icon type="material-community" name="email-outline" color={appColors.primary} />
                            </View>
                        }
                        errorMessage={formik.touched.email && formik.errors.email ? formik.errors.email : undefined}
                        errorStyle={{ paddingHorizontal: 35 }}
                        inputStyle={{ marginLeft: 65, height: 55, marginRight: 10 }}
                        inputContainerStyle={{ borderWidth: 0, borderBottomWidth: 0, backgroundColor: "white", borderRadius: 25, elevation: 5 }}
                    />
                    <Input
                        placeholder="Password"
                        value={formik.values.password}
                        onChangeText={(text) => formik.setFieldValue("password", text)}
                        onBlur={() => { formik.setFieldTouched("password", true); formik.handleBlur("password") }}
                        leftIcon={
                            <View style={{ backgroundColor: "white", paddingVertical: 20, paddingHorizontal: 20, borderRadius: 35, elevation: 5, position: "absolute", marginLeft: 40 }}>
                                <Icon type="material-community" name="lock-outline" color={appColors.primary} />
                            </View>
                        }
                        secureTextEntry={!eye}
                        rightIcon={
                            <Pressable style={{ paddingHorizontal: 15 }} onPress={() => setEye(!eye)}>
                                <Icon type="material-community" name={eye ? "eye" : "eye-off"} color={appColors.primary} size={20} />
                            </Pressable>
                        }
                        errorMessage={formik.touched.password && formik.errors.password ? formik.errors.password : undefined}
                        errorStyle={{ paddingHorizontal: 35 }}
                        inputStyle={{ height: 55, marginLeft: 65 }}
                        inputContainerStyle={{ borderWidth: 0, borderBottomWidth: 0, backgroundColor: "white", borderRadius: 25, elevation: 5 }}
                    />
                    <TouchableOpacity onPress={() => formik.handleSubmit()} activeOpacity={0.7} style={{ backgroundColor: appColors.primary, marginHorizontal: 15, paddingVertical: 15, alignItems: "center", borderRadius: 10, marginTop: 20 }}>
                        {loader ? <ActivityIndicator color={appColors.light} /> : <Text style={{ fontFamily: appFont.bold, color: appColors.light }}>Login</Text>}
                    </TouchableOpacity>
                    <View style={{ flexDirection: "row", alignItems: "center", marginTop: 30, paddingHorizontal: 15 }}>
                        <Divider style={{ flex: 1 }} />
                        <Text style={{ paddingHorizontal: 7, fontFamily: appFont.medium, color: appColors.grey, fontSize: 12 }}>Or Signin with</Text>
                        <Divider style={{ flex: 1 }} />
                    </View>
                    <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-evenly", marginTop: 20 }}>
                        <TouchableOpacity>
                            <Image source={require("../../assets/images/google.png")} style={{ height: 35, width: 35 }} />
                        </TouchableOpacity>
                        <TouchableOpacity>
                            <Image source={require("../../assets/images/facebook.png")} style={{ height: 42, width: 42 }} />
                        </TouchableOpacity>
                        <TouchableOpacity>
                            <Image source={require("../../assets/images/twitter.png")} style={{ height: 32, width: 32 }} />
                        </TouchableOpacity>
                    </View>
                    <Text style={{ fontFamily: appFont.medium, color: appColors.grey, marginTop: 30, textAlign: "center", paddingBottom: 20 }}>Don't have an account? <Text onPress={() => navigation.navigate("signup")} style={{ color: appColors.primary, textDecorationLine: "underline" }}>SignUp</Text></Text>
                </View>
            </ScrollView>
        </KeyboardAvoidingView>
    )
}

export default Login