import { useContext, useEffect, useState } from "react"
import { ActivityIndicator, Alert, FlatList, Image, Pressable, StatusBar, Text, TouchableOpacity, View } from "react-native"
import { Card, Icon } from "@rneui/themed"
import AsyncStorage from "@react-native-async-storage/async-storage"

import { appColors } from "../../shared/appColor"
import { appFont } from "../../shared/appFont"
import UserContext from "../../shared/userContext"

const Dashboard = () => {
    const [user, setUser] = useState<{ ip: string, country: string }>()
    const [loader, setLoader] = useState(false)
    const [data, setData] = useState()
    const [userData, setUserData] = useState<{ Role: string, Username: string }>()
    const { setIsLogedIn } = useContext(UserContext)

    const getIp = async () => {
        try {
            setLoader(true)
            const ipRes = await fetch("https://api.ipify.org?format=json");
            if (!ipRes.ok) throw new Error(`IP lookup failed: ${ipRes.status}`);
            const { ip } = await ipRes.json();

            const whoRes = await fetch(`https://ipwho.is/${ip}`);
            if (!whoRes.ok) throw new Error(`Location lookup failed: ${whoRes.status}`);
            const whoData = await whoRes.json();

            setUser({ ip, country: whoData.country });

            const asyncLogIn = await AsyncStorage.getItem("userID")
            const user = await AsyncStorage.getItem("allUsers")
            const parsedUser = JSON.parse(user!)
            const loginUser = parsedUser?.find((item: { UserId: string }) => item?.UserId == asyncLogIn)
            setUserData(loginUser)
            setLoader(false)
        } catch (error) {
            console.log("Error in dashboard", error)
        }
    }

    useEffect(() => {
        getIp()
    }, [])

    const fetchUserData = async () => {
        const user = await AsyncStorage.getItem("allUsers")
        const parsedUser = JSON.parse(user!)
        const filterData = parsedUser?.filter((item: { Role: string }) => (item?.Role?.toLowerCase() == "user"))
        if (filterData?.length > 0) {
            setData(filterData)
        } else {
            Alert.alert("Warning", "Currently you don't have any users")
        }
    }

    const logout = async () => {
        await AsyncStorage.removeItem("userID")
        setIsLogedIn(false)
    }

    const renderItem = ({ item, index }: { item: { Username: string, Email: string }, index: number }) => {
        return (
            <View key={index}>
                <Card containerStyle={{ borderRadius: 5 }}>
                    <View style={{ flexDirection: "row" }}>
                        <Text style={{ flex: 0.4, fontFamily: appFont.medium }}>UserName :</Text>
                        <Text style={{ flex: 0.6, fontFamily: appFont.bold }}>{item?.Username}</Text>
                    </View>
                    <View style={{ flexDirection: "row", marginTop: 10 }}>
                        <Text style={{ flex: 0.4, fontFamily: appFont.medium }}>User Email :</Text>
                        <Text style={{ flex: 0.6, fontFamily: appFont.bold }}>{item?.Email}</Text>
                    </View>
                </Card>
            </View>
        )
    }

    return (
        <View style={{ flex: 1 }}>
            <StatusBar backgroundColor={appColors.primary} />
            {loader ?
                <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
                    <ActivityIndicator size={"large"} color={appColors.primary} />
                </View> :
                <View style={{ flex: 1 }}>
                    <FlatList
                        keyExtractor={(item, index) => index.toString()}
                        data={data}
                        renderItem={renderItem}
                        showsVerticalScrollIndicator={false}
                        ListHeaderComponent={
                            <View style={{ marginTop: 20 }}>
                                <View style={{ paddingHorizontal: 20, flexDirection: "row", alignItems: "center" }}>
                                    <Text style={{ flex: 0.8, fontSize: 16, fontFamily: appFont.bold }}>Welcome {userData?.Username}!</Text>
                                    <Pressable style={{ flex: 0.2, alignItems: "flex-end" }} onPress={() => logout()}>
                                        <Icon type="material-community" name="logout" color={appColors.grey} size={25} />
                                    </Pressable>
                                </View>
                                <Card containerStyle={{ borderRadius: 5, justifyContent: "center", alignItems: "center", paddingBottom: 30 }}>
                                    <Image source={require('../../assets/images/welcome.png')} style={{ height: 200, width: 200 }} />
                                    <View style={{ flexDirection: "row" }}>
                                        <Text style={{ flex: 0.5, fontFamily: appFont.medium }}>IP Address :</Text>
                                        <Text style={{ flex: 0.5, fontFamily: appFont.bold }}>{user?.ip}</Text>
                                    </View>
                                    <View style={{ flexDirection: "row", marginTop: 10 }}>
                                        <Text style={{ flex: 0.5, fontFamily: appFont.medium }}>Country :</Text>
                                        <Text style={{ flex: 0.5, fontFamily: appFont.bold }}>{user?.country}</Text>
                                    </View>
                                    {userData?.Role?.toLowerCase() == "admin" ?
                                        <TouchableOpacity onPress={() => fetchUserData()} style={{ backgroundColor: appColors.primary, borderRadius: 5, alignItems: "center", alignSelf: "center", paddingVertical: 10, marginTop: 20, width: 100 }}>
                                            <Text style={{ color: appColors.light, fontFamily: appFont.medium }}>Get User</Text>
                                        </TouchableOpacity> : null}
                                </Card>
                            </View>
                        }
                        contentContainerStyle={{ paddingBottom: 50 }}
                    />
                </View>}
        </View>
    )
}

export default Dashboard