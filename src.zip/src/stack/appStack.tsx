import { createNativeStackNavigator } from "@react-navigation/native-stack"
import Profile from "../components/profile"
import Dashboard from "../components/dashboard/dashboard"

const AppStack = () => {
    const Navigation = createNativeStackNavigator()
    return (
        <Navigation.Navigator screenOptions={{ headerShown: false }} initialRouteName="dashboard">
            <Navigation.Screen name="dashboard" component={Dashboard} />
        </Navigation.Navigator>
    )
}

export default AppStack