import { createNativeStackNavigator } from "@react-navigation/native-stack"
import GetStarted from "../components/auth/getStarted"
import Login from "../components/auth/login"
import SignUp from "../components/auth/signUp"

const AuthStack = () => {
    const Navigator = createNativeStackNavigator()
    return (
        <Navigator.Navigator initialRouteName="signup" screenOptions={{ headerShown: false }}>
            <Navigator.Screen name="login" component={Login} />
            <Navigator.Screen name="signup" component={SignUp} />
        </Navigator.Navigator>
    )
}

export default AuthStack