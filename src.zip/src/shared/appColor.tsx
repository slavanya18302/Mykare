export const appColors = {
    primary: "#133B5C",
    light: "white",
    dark: "black",
    grey: "grey",
    transparent: "rgba(116, 136, 115, 0.2)"
}