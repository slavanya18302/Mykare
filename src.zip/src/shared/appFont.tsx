export const appFont={
    bold:"MontserratAlternates-Bold",
    medium:"MontserratAlternates-Medium"
}