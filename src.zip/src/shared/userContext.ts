import { createContext, Dispatch, SetStateAction } from "react";

interface IUserContext {
    isLogedIn: boolean;
    setIsLogedIn: Dispatch<SetStateAction<boolean>>;
}

const UserContext = createContext<IUserContext>({
    isLogedIn: false,
    setIsLogedIn: () => { }
})

export default UserContext